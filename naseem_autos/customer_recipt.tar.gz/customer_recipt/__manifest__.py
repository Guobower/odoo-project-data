{
	'name': 'Customer Recipts Summary', 
	'description': 'View your arranged Customer Recipts', 
	'author': 'Muhammad Kamran',
	'depends': ['base', 'report','account_accountant'], 
	'data': [
        'template.xml',
        'views/module_report.xml',
    ],
}