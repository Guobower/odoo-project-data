{
	'name': 'Top Sales Wise Report', 
	'description': 'View your cities and catagory wise Reports.', 
	'author': 'Muhammad Kamran',
	'depends': ['base', 'report','sale'], 
	'data': [
        'template.xml',
        'views/module_report.xml',
    ],
}