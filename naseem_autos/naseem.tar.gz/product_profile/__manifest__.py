{
	'name': 'Product Profile', 
	'description': 'Manage your product profiles.', 
	'author': 'Muhammad Kamran',
	'depends': ['base', 'report','sale'], 
	'data': [
        'template.xml',
        'views/module_report.xml',
    ],
}