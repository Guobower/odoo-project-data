{
	'name': 'Product Profit Report', 
	'description': 'View the profits as per your product.', 
	'author': 'Muhammad Kamran',
	'depends': ['base', 'report','sale'], 
	'data': [
        'template.xml',
        'views/module_report.xml',
    ],
}