# -*- coding: utf-8 -*-
{
    'name': "Fabrics Plan",
    'description': "Fabrics Plan",
    'author': 'Nayyab',
    'application': True,
    'depends': ['base'],
    'data': ['template.xml','views/module_report.xml'],
}