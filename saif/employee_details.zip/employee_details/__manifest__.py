# -*- coding: utf-8 -*-
{
    'name': "Employee Detail",
    'description': "Employee Detail",
    'author': 'Nayyab',
    'application': True,
    'depends': ['base'],
    'data': ['template.xml','views/module_report.xml'],
}