# -*- coding: utf-8 -*-
{
    'name': "UFC Sales Invoice",
    'description': "UFC Sales Invoice",
    'author': 'Nayyab',
    'application': True,
    'depends': ['base'],
    'data': ['template.xml','views/module_report.xml'],
}