# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

{
    'name': 'customer_payments_bcube_ufc',
    'author': 'bcube',
    'summary': 'Managing customer payments',
    'version': '1',
    'depends': ['base','account'],
    'data': [ 'templates.xml'],
    'installable': True,
    'auto_install': False
}
