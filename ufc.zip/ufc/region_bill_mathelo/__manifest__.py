# -*- coding: utf-8 -*-
{
    'name': "Region Wise Bill Mathelo",
    'description': "Region Wise Bill Mathelo",
    'author': 'Nayyab',
    'application': True,
    'depends': ['base'],
    'data': ['template.xml','views/module_report.xml'],
}