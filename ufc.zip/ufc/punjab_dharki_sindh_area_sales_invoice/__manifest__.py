# -*- coding: utf-8 -*-
{
    'name': "Punjab Dharki Sindh Area Sales Invoice",
    'description': "Punjab Dharki Sindh Area Sales Invoice",
    'author': 'Nayyab',
    'application': True,
    'depends': ['base','account'],
    'data': ['template.xml','views/module_report.xml'],
}