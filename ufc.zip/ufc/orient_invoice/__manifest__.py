# -*- coding: utf-8 -*-
{
    'name': "Orient Invoice",
    'description': "Orient Invoice",
    'author': 'Nayyab',
    'application': True,
    'depends': ['base','account'],
    'data': ['template.xml','views/module_report.xml'],
}