# -*- coding: utf-8 -*-
{
    'name': "Sindh Dharki Sales Invoice",
    'description': "Sindh Dharki Sales Invoice",
    'author': 'Nayyab',
    'application': True,
    'depends': ['base','account'],
    'data': ['template.xml','views/module_report.xml'],
}