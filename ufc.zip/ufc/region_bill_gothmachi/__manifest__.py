# -*- coding: utf-8 -*-
{
    'name': "Region Wise Bill Gothmachi",
    'description': "Region Wise Bill Gothmachi",
    'author': 'Nayyab',
    'application': True,
    'depends': ['base'],
    'data': ['template.xml','views/module_report.xml'],
}