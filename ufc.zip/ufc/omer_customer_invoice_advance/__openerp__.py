# -*- coding: utf-8 -*-
{
    'name': "Omer Fiaz - Customer Invoice Advance",

    'summary': "Omer Fiaz - Customer Invoice Advance",

    'description': "Omer Fiaz - Customer Invoice Advance",

    'author': "Muhammad Kamran",
    'website': "http://www.bcube.com",

    # any module necessary for this one to work correctly
    'depends': ['base'],
    # always loaded
    'data': [
        'template.xml',
        'views/module_report.xml',
    ],
    'css': ['static/src/css/report.css'],
}
