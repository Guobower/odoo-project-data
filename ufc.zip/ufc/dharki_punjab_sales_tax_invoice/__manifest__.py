# -*- coding: utf-8 -*-
{
    'name': "Dharki Punjab Sales Tax Invoice",
    'description': "Dharki Punjab Sales Tax Invoice",
    'author': 'Nayyab',
    'application': True,
    'depends': ['base','account'],
    'data': ['template.xml','views/module_report.xml'],
}