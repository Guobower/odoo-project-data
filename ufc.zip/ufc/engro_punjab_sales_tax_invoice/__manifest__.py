# -*- coding: utf-8 -*-
{
    'name': " Engro Punjab Sales Tax Invoice",
    'description': "Engro Punjab Sales Tax Invoice",
    'author': 'Nayyab',
    'application': True,
    'depends': ['base','account'],
    'data': ['template.xml','views/module_report.xml'],
}