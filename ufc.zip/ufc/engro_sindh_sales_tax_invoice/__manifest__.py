# -*- coding: utf-8 -*-
{
    'name': " Engro Sindh Sales Tax Invoice",
    'description': "Engro Sindh Sales Tax Invoice",
    'author': 'Nayyab',
    'application': True,
    'depends': ['base','account'],
    'data': ['template.xml','views/module_report.xml'],
}