# -*- coding: utf-8 -*-
{
    'name': "Region Bill Detail",
    'description': "Region Bill Detail",
    'author': 'Nayyab',
    'application': True,
    'depends': ['base','summary_ffc','ufc_automization_10'],
    'data': ['template.xml','views/module_report.xml'],
}