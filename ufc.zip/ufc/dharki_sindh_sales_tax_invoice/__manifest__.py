# -*- coding: utf-8 -*-
{
    'name': "Dharki Sindh Sales Tax Invoice",
    'description': "Dharki Sindh Sales Tax Invoice",
    'author': 'Nayyab',
    'application': True,
    'depends': ['base','account'],
    'data': ['template.xml','views/module_report.xml'],
}