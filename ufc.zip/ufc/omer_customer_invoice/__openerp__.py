# -*- coding: utf-8 -*-
{
    'name': "Omer Fiaz - Customer Invoice",

    'summary': "Omer Fiaz - Customer Invoice",

    'description': "Omer Fiaz - Customer Invoice",

    'author': "Muhammad Kamran",
    'website': "http://www.bcube.com",

    # any module necessary for this one to work correctly
    'depends': ['base'],
    # always loaded
    'data': [
        'template.xml',
        'views/module_report.xml',
    ],
    'css': ['static/src/css/report.css'],
}
