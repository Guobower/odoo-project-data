{
	'name': 'Saif Employee Modifications', 
	'description': 'Saif Employee Modifications',
	'author': 'Muhammad Awais', 
	'depends': ['project','hr'], 
	'application': True,
	'data': ['views/template.xml'],
}